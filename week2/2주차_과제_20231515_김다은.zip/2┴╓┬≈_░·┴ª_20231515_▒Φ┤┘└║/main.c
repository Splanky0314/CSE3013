#include "header.h"

int main() {
    int t, n;
    scanf("%d", &t);

    // 각 숫자의 수를 저장할 배열 할당
    int* arr = (int*)malloc(sizeof(int)*10);
    for(int T=0; T<t; T++) {
        
        // 배열 arr을 0으로 초기화
        for(int i=0; i<10; i++) {
            arr[i] = 0;
        }

        scanf("%d", &n);
        // 0~9의 등장 횟수 세기
        count(n, arr);

        // 결과 출력
        print(arr);

        
    }
    // 동적 할당 free
    free(arr);
    return 0;
}
