#include <stdio.h>
#include <stdlib.h>

void count(int x, int* array);
void print(int* array);
