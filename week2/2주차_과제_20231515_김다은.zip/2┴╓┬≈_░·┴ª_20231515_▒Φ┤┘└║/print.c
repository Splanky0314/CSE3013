#include "header.h"

// 배열을 형식에 맞추어 출력하는 함수
void print(int *array) {
    // 0~9까지의 수에 대해
    for(int i=0; i<10; i++) {
        // 각 숫자가 등장한 횟수(배열의 값) 출력
        printf("%d ", array[i]);
    }
    printf("\n");
}
