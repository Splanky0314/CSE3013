#include "header.h"

// 0~9의 등장 횟수를 세는 함수
// x: n(페이지 쪽수)
// array: 0~9의 등장 횟수를 저장한 배열
void count(int x, int* array) {
    // 페이지 1~x에 대하여
    for(int i=1; i<=x; i++) {
        int tmp = i;
        while(tmp!=0) {
            // tmp의 1의 자리 숫자 index를 가진 원소에 +1
            array[tmp%10]++;
            // 다음 자리의 숫자를 세기 위해 tmp/=10
            tmp/=10;
        }
    }
}
