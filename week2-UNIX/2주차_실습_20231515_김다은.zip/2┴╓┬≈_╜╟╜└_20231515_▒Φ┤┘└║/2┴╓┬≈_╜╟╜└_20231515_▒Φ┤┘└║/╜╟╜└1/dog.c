#include "header.h"

void dog() {
	printf("It's dog.c");
}
