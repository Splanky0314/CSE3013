#include "header.h"

void blackcow() {
	printf("It's blackcow.c");
}
