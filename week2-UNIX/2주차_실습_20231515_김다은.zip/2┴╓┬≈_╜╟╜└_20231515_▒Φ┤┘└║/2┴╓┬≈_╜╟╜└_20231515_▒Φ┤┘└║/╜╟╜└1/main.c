#include <stdio.h>

int main() {
	printf("It's main");

	printf("\n");
	dog();
	printf("\n");
	turtle();
	printf("\n");
	blackcow();
}
