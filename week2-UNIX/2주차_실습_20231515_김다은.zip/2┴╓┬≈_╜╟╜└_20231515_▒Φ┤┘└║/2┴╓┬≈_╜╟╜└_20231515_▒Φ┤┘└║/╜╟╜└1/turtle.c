#include "header.h"

void turtle() {
	printf("It's turtle.c");
}
