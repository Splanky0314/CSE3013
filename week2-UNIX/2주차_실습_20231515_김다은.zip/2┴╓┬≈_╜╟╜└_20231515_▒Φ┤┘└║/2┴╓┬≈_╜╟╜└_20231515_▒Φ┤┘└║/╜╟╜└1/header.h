#include <stdio.h>

void turtle();
void blackcow();
void dog();
